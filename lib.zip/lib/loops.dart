void main(){

  /*for(int a = 10; a>=3; a--){
    print("$a. Hello World!!");
  }*/

  int a = 100;

  while(a<=99){
    print("Hello World!!");
    a--;
  }

}